/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body for the Fishing Game
  ******************************************************************************
  * @author         : Your Name
  * @brief          : This game involves catching fish and engaging in a
  * time-sensitive fight minigame.
  * @attention      : Ensure game.h and assets.h are included in your project.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "rng.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// ILI9341 Driver Files
#include "ILI9341_STM32_Driver.h"
#include "ILI9341_GFX.h"
#include "ILI9341_Touchscreen.h"

// Game-specific files we created
#include "game.h"
#include "assets.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// FIX: Structs moved here for clarity, but they should be in game.h
//typedef struct {
//    float x, y;
//    float old_x, old_y; // Track previous position
//    int direction;
//    FishKind kind;
//    FishState state;
//    float base_decay, tug_strength, tug_rate, tug_timer, scared_timer;
//} Fish;
//
//typedef struct {
//    long score;
//    float boat_x;
//    float old_boat_x; // Track previous position
//    float hook_y;
//    float old_hook_y; // Track previous position
//} Player;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define FISH_SPEED 50.0f // Horizontal speed of fish in pixels/second
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
// --- Game Objects ---
Player player;
Fish fish_pool[MAX_FISH_ON_SCREEN];
Fish* hooked_fish = NULL;

// --- Game State Variables ---
GameState current_state = GAME_STATE_PLAY; // NEW: Game state machine
bool game_over = false;
bool fight_active = false;
float fight_meter = 0.0f;
float fight_time = 0.0f;
uint32_t last_time_left = 999; // Or any value that isn't GAME_DURATION_S
long last_score = -1;                     // FIX: To track when HUD needs updating
volatile uint32_t game_time_left = GAME_DURATION_S;

// --- Timing Variables ---
uint32_t start_tick;
uint32_t last_frame_tick;
uint32_t paused_ticks = 0; // NEW: To track time spent paused
uint32_t pause_start_tick = 0; // NEW: To correctly calculate pause duration



// --- NEW: Keyboard Input Variables ---
volatile uint8_t received_char = 0;
volatile bool new_key_pressed = true;

// --- Shop State Variables ---
int selected_boat_index = 0;
int selected_bait_index = 0;
bool redraw_shop = false; // NEW: Flag to control shop refreshing

// joy stick and button and rotary
uint8_t is_fishing = 0;

uint32_t adc_values[2];
GPIO_PinState sw_state;
char uart_buf[150];
volatile uint32_t encoder_count = 0;
volatile uint8_t encoder_state = 0;
uint32_t last_encoder_tick = 0;

volatile uint32_t encoder_fight = 10000;

const int8_t quad_table[16] = {
    0, -1, 1, 0,
    1, 0, 0, -1,
    -1, 0, 0, 1,
    0, 1, -1, 0
};

// shops
uint8_t b = 0;
uint8_t n = 0;
uint8_t space = 0;
uint8_t r = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void ILI9341_Draw_V_Line(uint16_t x, uint16_t y1, uint16_t y2, uint16_t color);
void Spawn_Fish(Fish* fish);
void Game_Init(Player* p, Fish pool[]);
void Handle_Input(Player* p, bool* is_fight_active, float* meter);

// Logic Updaters
void Update_Game_Logic(Player* p, Fish pool[], bool* is_fight_active, float* meter, float dt);

// FIX: Rendering functions are refactored
void Render_Background(void);
void Render_Static_HUD(void);
void Render_Updates(Player* p, const Fish pool[], uint32_t time_left, bool is_fight_active, float meter);
void Render_Game_Over_Screen(const Player* p);
void Render_Boat_Shop(const Player* p);
void Render_Bait_Shop(const Player* p);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Empty
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* Enable the CPU Cache */

  /* Enable I-Cache---------------------------------------------------------*/
  SCB_EnableICache();

  /* Enable D-Cache---------------------------------------------------------*/
  SCB_EnableDCache();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART3_UART_Init();
  MX_SPI5_Init();
  MX_TIM1_Init();
  MX_RNG_Init();
  MX_I2C1_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  ILI9341_Init();
  ILI9341_Set_Rotation(SCREEN_VERTICAL_1);

  HAL_ADC_Start_DMA(&hadc1, (uint32_t*) adc_values, 2);

  // rotary encoder
  Encoder_Init();

  // --- Initialize the Game ---
  Game_Init(&player, fish_pool);

  // --- FIX: Draw the static background and HUD only ONCE ---
  Render_Background();
  Render_Static_HUD();

  // --- NEW: Start listening for keyboard input ---
  HAL_UART_Receive_IT(&huart3, (uint8_t*)&received_char, 1);

  bool game_over_screen_drawn = false; // <-- ADD THIS LINE

  // start timer
  HAL_TIM_Base_Start_IT(&htim2);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  /* --- STATE MACHINE --- */
	    if (current_state == GAME_STATE_PLAY)
	    {
	        HAL_TIM_Base_Start_IT(&htim2);
	    }
	      switch (current_state)
	      {
	          case GAME_STATE_PLAY:
	          {
	              uint32_t current_tick = HAL_GetTick();
	              float dt = (current_tick - last_frame_tick) / 1000.0f;
	              last_frame_tick = current_tick;

	              Handle_Play_Input(&player, &fight_active, &fight_meter);
	              Update_Game_Logic(&player, fish_pool, &fight_active, &fight_meter, dt);


	              // --- NEW: Use our interrupt-driven timer variable ---
	              if (game_time_left == 0) {
	            	  HAL_TIM_Base_Stop_IT(&htim2); // <-- ADD THIS: STOP THE TIMER!
	                  current_state = GAME_STATE_OVER;

	              }

	              // Pass the new global variable to the render function
	              Render_Updates(&player, fish_pool, game_time_left, fight_active, fight_meter);

	              player.old_boat_x = player.boat_x;
	              player.old_hook_y = player.hook_y;
	              for(int i = 0; i < MAX_FISH_ON_SCREEN; i++) {
	                  fish_pool[i].old_x = fish_pool[i].x;
	                  fish_pool[i].old_y = fish_pool[i].y;
	              }
	              break;
	          }

	          case GAME_STATE_BOAT_SHOP:
	          {
	              Handle_Shop_Input(&player);
	              if (redraw_shop) {
	                Render_Boat_Shop(&player);
	                redraw_shop = false;
	              }
	              break;
	           }
	          case GAME_STATE_BAIT_SHOP:
	          		{
	          			Handle_Shop_Input(&player);
	                      if (redraw_shop) {
	          			    Render_Bait_Shop(&player);
	                          redraw_shop = false;
	                      }
	          			break;
	          		}

	          case GAME_STATE_OVER:
	          {
	              static bool game_over_screen_drawn = false;
	              if (!game_over_screen_drawn) {
	                  Render_Game_Over_Screen(&player);
	                  game_over_screen_drawn = true;
	              }
	              if (r) {

	                  Game_Init(&player, fish_pool); // Re-initializes everything
	                  HAL_TIM_Base_Start_IT(&htim2); // <-- ADD THIS: RESTART THE TIMER!
	                  current_state = GAME_STATE_PLAY;
	                  game_over_screen_drawn = false;
	                  r = 0;
	                  Render_Background();
	                  Render_Static_HUD();
	              }
	              break;
	          }
	      }

	      sw_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);

		  sprintf(uart_buf,
			   "X: %lu Y: %lu Rotary: %lu Fight: %lu\r\n",
			   adc_values[0],
			   adc_values[1],
			   encoder_count,
			   encoder_fight);

		  HAL_UART_Transmit(&huart3, (uint8_t*)uart_buf, strlen(uart_buf), HAL_MAX_DELAY);

	      HAL_Delay(16);
	    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    // Check if the interrupt came from TIM2
    if (htim->Instance == TIM2)
    {
        // If there's time left, count down.
        if (game_time_left > 0)
        {
            game_time_left--;
        }
    }
}

void Vibration_Start(uint8_t intensity_percent)
{
    if (intensity_percent > 100) intensity_percent = 100;

    // Calculate the corresponding compare value for TIM3
    uint32_t arr = htim3.Init.Period;           // TIM3 auto-reload value
    uint32_t compare = (arr * intensity_percent) / 100;

    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, compare);

    // Ensure PWM output is running
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
}

void Vibration_Stop(void)
{
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0); // Set duty cycle to 0
    // Optionally stop PWM if you want to completely disable output
    // HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_3);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == GPIO_PIN_9 || GPIO_Pin == GPIO_PIN_13) { // Either encoder pin
        uint8_t a = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_9);
        uint8_t b = HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_13);
        uint8_t new_state = (a << 1) | b;

        uint8_t index = (encoder_state << 2) | new_state;
        int8_t delta = quad_table[index];


		if (!fight_active) {
			if (delta < 0 && encoder_count == 0) {
				// Do nothing
			}
			else
				encoder_count += delta;
		}
		else {
			if (delta < 0 && encoder_fight == 0) {
				// Do nothing
			}
			else
				encoder_fight += delta;
		}

        encoder_state = new_state;
    }

    if(GPIO_Pin == GPIO_PIN_4) { // Fishing button

    	uint32_t now = HAL_GetTick(); // ms
		if(now - last_encoder_tick < 200) return; // ignore fast bounces
		last_encoder_tick = now;

        is_fishing = !is_fishing;
        char* msg = is_fishing ? "🎣 Fishing started!\r\n" : "🛑 Fishing stopped.\r\n";
        HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }

    if(GPIO_Pin == GPIO_PIN_11) {
		uint32_t now = HAL_GetTick(); // ms
		if(now - last_encoder_tick < 200) return; // ignore fast bounces
		last_encoder_tick = now;
		b = 1;
		char* msg ="Open boat shop!\r\n";
		HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }

    if(GPIO_Pin == GPIO_PIN_0) {
    	uint32_t now = HAL_GetTick(); // ms
		if(now - last_encoder_tick < 200) return; // ignore fast bounces
		last_encoder_tick = now;

	    n = 1;
	    char* msg ="Open bait shop!\r\n";
	    HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }

    if(GPIO_Pin == GPIO_PIN_10) {
    	uint32_t now = HAL_GetTick(); // ms
		if(now - last_encoder_tick < 200) return; // ignore fast bounces
		last_encoder_tick = now;

	    space = 1;
	    char* msg ="buy boat!\r\n";
	    HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }

    if(GPIO_Pin == GPIO_PIN_15) {

    	uint32_t now = HAL_GetTick(); // ms
		if(now - last_encoder_tick < 200) return; // ignore fast bounces
		last_encoder_tick = now;

	    r = 1;
	    char* msg ="Reset!\r\n";
	    HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    }

}

void Encoder_Init(void) {
    uint8_t a = HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_9);
    uint8_t b = HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_13);
    encoder_state = (a << 1) | b;
}

// --- SHOP RENDERING FUNCTIONS ---
void Render_Boat_Shop(const Player* p) {
    char text_buffer[50];

    ILI9341_Fill_Screen(SHOP_BG_COLOR);
    ILI9341_Draw_Filled_Rectangle_Coord(0, 0, SCREEN_WIDTH - 1, 40, SHOP_HEADER_BG_COLOR);
    ILI9341_Draw_Text("Boat Shop", 75, 15, BLACK, 2, SHOP_HEADER_BG_COLOR);

    sprintf(text_buffer, "Money: $%ld", p->score);
    ILI9341_Draw_Text(text_buffer, 20, 60, WHITE, 2, SHOP_BG_COLOR);

    const BoatInfo* boat = &BOAT_CATALOG[selected_boat_index];
    ILI9341_Draw_Text(boat->name, 20, 120, WHITE, 2, SHOP_BG_COLOR);

//    Draw_Boat(205, 134);

    // --- DIRECT DRAWING LOGIC ---
    // This code bypasses Draw_Boat() to guarantee the correct position.

    // 1. Select the correct boat sprite to display
    const uint16_t* boat_sprite_to_draw = boat_sprite_data;
    switch(selected_boat_index) {
        case BOAT_SHARK:     boat_sprite_to_draw = shark_boat_sprite_data; break;
        case BOAT_SPEEDBOAT: boat_sprite_to_draw = speedboat_sprite_data; break;
        case BOAT_SAILOR:    boat_sprite_to_draw = sailor_boat_sprite_data; break;
        default:             boat_sprite_to_draw = boat_sprite_data; break;
    }

    // 2. Calculate the top-left corner for drawing on the far right
    uint16_t start_x = SCREEN_WIDTH - BOAT_SPRITE_WIDTH - 20; // 20px padding from the right edge
    uint16_t start_y = 110;

    // 3. Draw the sprite pixel by pixel
    const uint16_t transparent_color = 0xF81F;
    for (uint16_t j = 0; j < BOAT_SPRITE_HEIGHT; j++) {
        for (uint16_t i = 0; i < BOAT_SPRITE_WIDTH; i++) {
            uint16_t current_pixel_color = boat_sprite_to_draw[j * BOAT_SPRITE_WIDTH + i];
            if (current_pixel_color != transparent_color) {
                ILI9341_Draw_Pixel(start_x + i, start_y + j, current_pixel_color);
            }
        }
    }
    // --- END OF DIRECT DRAWING LOGIC ---

    if (p->boats_owned[selected_boat_index]) {
        if (p->equipped_boat == selected_boat_index) {
            ILI9341_Draw_Text("Equipped", 20, 180, CYAN, 2, SHOP_BG_COLOR);
        } else {
            ILI9341_Draw_Text("Press SPACE to equip", 20, 180, GREEN, 2, SHOP_BG_COLOR);
        }
    } else {
        sprintf(text_buffer, "Price: $%d", boat->price);
        ILI9341_Draw_Text(text_buffer, 20, 180, YELLOW, 2, SHOP_BG_COLOR);
    }
}

// --- UPDATED BAIT SHOP RENDERER ---
void Render_Bait_Shop(const Player* p) {
    char text_buffer[50];
    const BaitInfo* bait = &BAIT_CATALOG[selected_bait_index];

    ILI9341_Fill_Screen(SHOP_BG_COLOR);
    ILI9341_Draw_Filled_Rectangle_Coord(0, 0, SCREEN_WIDTH - 1, 40, SHOP_HEADER_BG_COLOR);
    ILI9341_Draw_Text("Bait Shop", 75, 15, BLACK, 2, SHOP_HEADER_BG_COLOR);

    sprintf(text_buffer, "Money: $%ld", p->score);
    ILI9341_Draw_Text(text_buffer, 20, 60, WHITE, 2, SHOP_BG_COLOR);

    // --- COLOR CHANGE: Use the color from the catalog ---
    ILI9341_Draw_Text(bait->name, 20, 120, bait->color, 2, SHOP_BG_COLOR);

    if (p->baits_owned[selected_bait_index]) {
        if (p->equipped_bait == selected_bait_index) {
            ILI9341_Draw_Text("Equipped", 20, 180, CYAN, 2, SHOP_BG_COLOR);
        } else {
            ILI9341_Draw_Text("Press SPACE to equip", 20, 180, GREEN, 2, SHOP_BG_COLOR);
        }
    } else {
        sprintf(text_buffer, "Price: $%d", bait->price);
        ILI9341_Draw_Text(text_buffer, 20, 180, YELLOW, 2, SHOP_BG_COLOR);
    }
}


/**
 * @brief Draws the full-screen game over message.
 * @param p Pointer to the player to get the final score.
 */
void Render_Game_Over_Screen(const Player* p)
{
    char text_buffer[50];

    // Clear the entire screen to black
    ILI9341_Fill_Screen(BLACK);

    // Draw "GAME OVER" large and centered
    ILI9341_Draw_Text("GAME OVER", 48, 110, RED, 3, BLACK);

    // Draw the final score below, medium-sized and centered
    sprintf(text_buffer, "Final Score: $%ld", p->score);
    ILI9341_Draw_Text(text_buffer, 35, 150, WHITE, 2, BLACK);

    // Draw the restart message small, near the bottom
    ILI9341_Draw_Text("Press any key to play again", 30, 220, WHITE, 1, BLACK);
}

void Draw_Boat(float x, float y) {
    const uint16_t* boat_sprite_to_draw = boat_sprite_data;
    BoatType boat_to_show = player.equipped_boat;

    if (current_state == GAME_STATE_BOAT_SHOP) {
        boat_to_show = (BoatType)selected_boat_index;
    }

    switch(boat_to_show) {
        case BOAT_SHARK:     boat_sprite_to_draw = shark_boat_sprite_data; break;
        case BOAT_SPEEDBOAT: boat_sprite_to_draw = speedboat_sprite_data; break;
        case BOAT_SAILOR:    boat_sprite_to_draw = sailor_boat_sprite_data; break;
        default:             boat_sprite_to_draw = boat_sprite_data; break;
    }

    uint16_t start_x = (uint16_t)(x - (BOAT_SPRITE_WIDTH / 2));
    uint16_t start_y = (uint16_t)(y - BOAT_SPRITE_HEIGHT);
    const uint16_t transparent_color = 0xF81F;

    for (uint16_t j = 0; j < BOAT_SPRITE_HEIGHT; j++) {
        for (uint16_t i = 0; i < BOAT_SPRITE_WIDTH; i++) {
            uint16_t current_pixel_color = boat_sprite_to_draw[j * BOAT_SPRITE_WIDTH + i];
            if (current_pixel_color != transparent_color) {
                ILI9341_Draw_Pixel(start_x + i, start_y + j, current_pixel_color);
            }
        }
    }
}

void Draw_Fish(uint16_t x, uint16_t y, FishKind kind) {
    uint16_t width = 0, height = 0;
    const uint16_t* sprite_data = NULL;

    // Select the correct sprite data and dimensions
    switch (kind) {
        case FISH_KIND_GOLD:
            width = GOLDFISH_SPRITE_WIDTH;
            height = GOLDFISH_SPRITE_HEIGHT;
            sprite_data = goldfish_sprite_data;
            break;
        case FISH_KIND_BLUE:
            width = BLUEFISH_SPRITE_WIDTH;
            height = BLUEFISH_SPRITE_HEIGHT;
            sprite_data = bluefish_sprite_data;
            break;
        case FISH_KIND_PUFFER:
            width = PUFFERFISH_SPRITE_WIDTH;
            height = PUFFERFISH_SPRITE_HEIGHT;
            sprite_data = pufferfish_sprite_data;
            break;
        case FISH_KIND_SHARK:
            width = SHARK_SPRITE_WIDTH;
            height = SHARK_SPRITE_HEIGHT;
            sprite_data = shark_sprite_data;
            break;
    }

    if (sprite_data == NULL) return;

    // Define the magenta color key for transparency
    const uint16_t transparent_color = 0xF81F;

    // Loop through every pixel
    for (uint16_t j = 0; j < height; j++) {
        for (uint16_t i = 0; i < width; i++) {
            uint16_t current_pixel_color = sprite_data[j * width + i];

            // If the pixel is not transparent, draw it
            if (current_pixel_color != transparent_color) {
                // The byte-swap line that was here has been REMOVED
                ILI9341_Draw_Pixel(x + i, y + j, current_pixel_color);
            }
        }
    }
}


void ILI9341_Draw_V_Line(uint16_t x, uint16_t y1, uint16_t y2, uint16_t color)
{
    if (y1 > y2) {
        uint16_t temp = y1;
        y1 = y2;
        y2 = temp;
    }
    ILI9341_Draw_Filled_Rectangle_Coord(x, y1, x, y2, color);
}

void Spawn_Fish(Fish* fish)
{
    uint32_t random_val;
    HAL_RNG_GenerateRandomNumber(&hrng, &random_val);
    fish->kind = random_val % 4;
    fish->state = FISH_STATE_FREE;
    HAL_RNG_GenerateRandomNumber(&hrng, &random_val);
    fish->x = random_val % (SCREEN_WIDTH - 40);
    HAL_RNG_GenerateRandomNumber(&hrng, &random_val);


    // Calculate the total available swimming height
    uint16_t swimming_height = SCREEN_HEIGHT - WATER_LEVEL - SAND_HEIGHT - 20; // -20 for padding
    fish->y = (random_val % swimming_height) + WATER_LEVEL + 10; // +10 for padding

    HAL_RNG_GenerateRandomNumber(&hrng, &random_val);
    fish->direction = (random_val % 2) == 0 ? 1 : -1;

    // FIX: Initialize old positions to the starting positions
    fish->old_x = fish->x;
    fish->old_y = fish->y;

    switch (fish->kind) {
        case FISH_KIND_GOLD:
            fish->base_decay = 7.0f; fish->tug_strength = 5.0f; fish->tug_rate = 2.5f;
            break;
        case FISH_KIND_BLUE:
            fish->base_decay = 8.0f; fish->tug_strength = 6.5f; fish->tug_rate = 2.0f;
            break;
        case FISH_KIND_PUFFER:
            fish->base_decay = 9.5f; fish->tug_strength = 7.0f; fish->tug_rate = 1.5f;
            break;
        case FISH_KIND_SHARK:
            fish->base_decay = 15.0f; fish->tug_strength = 10.0f; fish->tug_rate = 1.2f;
            break;
    }
    fish->tug_timer = fish->tug_rate;
    fish->scared_timer = 0.0f;
}

void Game_Init(Player* p, Fish pool[])
{
	// --- FIX: Add these three lines to properly reset the game state ---
	game_time_left = GAME_DURATION_S; // The main fix for the timer
	last_score = -1;                  // Force the score to redraw
	last_time_left = 999;             // Force the time to redraw
	is_fishing = 0;

    p->score = PLAYER_START_SCORE;
    p->boat_x = SCREEN_WIDTH / 2.0f;
    p->hook_y = WATER_LEVEL + 30.0f;
    p->old_boat_x = p->boat_x;
    p->old_hook_y = p->hook_y;

    // NEW: Initialize player inventory
    p->equipped_boat = BOAT_NORMAL;
    p->equipped_bait = BAIT_REGULAR;
    for (int i = 0; i < BOAT_COUNT; i++) {
        p->boats_owned[i] = false;
    }
    // --- LOGIC CHANGE: Initialize baits_owned array ---
    for (int i = 0; i < BAIT_COUNT; i++) {
         p->baits_owned[i] = false;
    }
    p->boats_owned[BOAT_NORMAL] = true; // Player owns the first boat by default
    p->baits_owned[BAIT_REGULAR] = true; // Player owns regular bait by default


    for (int i = 0; i < MAX_FISH_ON_SCREEN; i++) {
        Spawn_Fish(&pool[i]);
    }
    start_tick = HAL_GetTick();
    last_frame_tick = start_tick;
    paused_ticks = 0; // Reset paused time
}

// --- NEW: Input handler for the shops ---
// --- UPDATED SHOP INPUT HANDLER ---
void Handle_Shop_Input(Player* p) {
    if (b || n) {
    	// --- TIMER FIX: Calculate total pause duration and add it ---
        HAL_TIM_Base_Start_IT(&htim2); // <-- RESUME THE TIMER
		current_state = GAME_STATE_PLAY;


        last_frame_tick = HAL_GetTick(); // <--- ADD THIS LINE

		last_score = -1;
		last_time_left = game_time_left + 1; // Set to an invalid time

		b = 0;
		n = 0;

		Render_Background();
		Render_Static_HUD();
    }

    const uint32_t DEADZONE = 500;        // for joystick X-axis
    uint32_t joy_x = adc_values[1];

    if (joy_x > 4095 / 2 + DEADZONE) {
    	if (current_state == GAME_STATE_BOAT_SHOP) {
			if (--selected_boat_index < 0) selected_boat_index = BOAT_COUNT - 1;
		} else {
			if (--selected_bait_index < 0) selected_bait_index = BAIT_COUNT - 1;
		}
		redraw_shop = true;
    }
    else if (joy_x < 4095 / 2 - DEADZONE) {
    	if (current_state == GAME_STATE_BOAT_SHOP) {
			if (++selected_boat_index >= BOAT_COUNT) selected_boat_index = 0;
		} else {
			if (++selected_bait_index >= BAIT_COUNT) selected_bait_index = 0;
		}
		redraw_shop = true;
    }
    else if (space) {
    	if (current_state == GAME_STATE_BOAT_SHOP) {
			if (p->boats_owned[selected_boat_index]) {
				p->equipped_boat = selected_boat_index;
			} else if (p->score >= BOAT_CATALOG[selected_boat_index].price) {
				p->score -= BOAT_CATALOG[selected_boat_index].price;
				p->boats_owned[selected_boat_index] = true;
				p->equipped_boat = selected_boat_index;
			}
		} else { // Bait Shop
			if (p->baits_owned[selected_bait_index]) {
				 p->equipped_bait = selected_bait_index;
			}
			else if (p->score >= BAIT_CATALOG[selected_bait_index].price) {
				p->score -= BAIT_CATALOG[selected_bait_index].price;
				p->baits_owned[selected_bait_index] = true;
				p->equipped_bait = selected_bait_index;
			}
		}
		redraw_shop = true;
		space = 0;
    }
}

// --- UPDATED PLAY INPUT HANDLER ---
void Handle_Play_Input(Player* p, bool* is_fight_active, float* meter)
{

	    const float BOAT_SPEED = 8.0f;        // adjust for feel
	    const float HOOK_MOVE_SPEED = 2.0f;   // multiplier for encoder
		#define FIGHT_PRESS_GAIN2  8.0f    // how much meter increases per tick CW
		#define FIGHT_PRESS_LOSS2 1.0f    // how much meter decreases per tick CCW

	    const uint32_t DEADZONE = 500;        // for joystick X-axis

	    uint32_t joy_x = adc_values[1];       // Joystick X controls boat

		// --- Fight Mode ---
	    static int32_t prev_encoder_fight = 500;
		if (*is_fight_active) {
			int32_t delta_fight = encoder_fight - prev_encoder_fight;
			if (delta_fight < 0) {
				*meter += FIGHT_PRESS_GAIN2;
			} else if  (delta_fight > 0){
				*meter -= FIGHT_PRESS_LOSS2;
			}
			prev_encoder_fight = encoder_fight;

			if (*meter > FIGHT_TARGET) *meter = FIGHT_TARGET;
			if (*meter < 0) *meter = 0;
		}

	    extern uint8_t is_fishing;
	    static int32_t prev_encoder = 0;  // track encoder delta

	    // --- Control boat movement (X-axis) ---
	    if (!is_fishing) {
	        if (joy_x > 4095 / 2 + DEADZONE) p->boat_x += BOAT_SPEED;
	        else if (joy_x < 4095 / 2 - DEADZONE) p->boat_x -= BOAT_SPEED;
	    }
	    else if (!*is_fight_active) {
	        // --- Control hook movement (Y-axis) via encoder ---
	        int32_t delta = encoder_count - prev_encoder;
	        if (delta != 0) {
	            p->hook_y += delta * HOOK_MOVE_SPEED; // adjust speed if too fast/slow
	            prev_encoder = encoder_count;
	        }
	    }

	    // --- Boundary Checks ---
	    if (p->boat_x < BOAT_SPRITE_WIDTH / 2)
	        p->boat_x = BOAT_SPRITE_WIDTH / 2;
	    if (p->boat_x > SCREEN_WIDTH - BOAT_SPRITE_WIDTH / 2)
	        p->boat_x = SCREEN_WIDTH - BOAT_SPRITE_WIDTH / 2;

	    if (p->hook_y < WATER_LEVEL)
	        p->hook_y = WATER_LEVEL;
	    if (p->hook_y > SCREEN_HEIGHT - HOOK_SPRITE_HEIGHT)
	        p->hook_y = SCREEN_HEIGHT - HOOK_SPRITE_HEIGHT;

	    if (b) {
	        HAL_TIM_Base_Stop_IT(&htim2); // <-- This is the new, correct way to pause
			current_state = GAME_STATE_BOAT_SHOP;
			redraw_shop = true;
			b = 0;
	    }
	    else if (n) {
	        HAL_TIM_Base_Stop_IT(&htim2); // <-- This is the new, correct way to pause
			current_state = GAME_STATE_BAIT_SHOP;
			redraw_shop = true;
			n = 0;
	    }
}


void Update_Game_Logic(Player* p, Fish pool[], bool* is_fight_active, float* meter, float dt)
{
    if (*is_fight_active && hooked_fish != NULL)
    {
    	Vibration_Start(htim3.Init.Period); // vibrate

        if (*meter >= FIGHT_TARGET) {
            p->score += FISH_CATCH_SCORE;
            *is_fight_active = false;
            encoder_fight = 10000;
            hooked_fish->state = FISH_STATE_INACTIVE;
            hooked_fish = NULL;
            return;
        }
        if (*meter <= 0 || fight_time >= FIGHT_TIMEOUT_S) {
            *is_fight_active = false;
            encoder_fight = 10000;
            hooked_fish->state = FISH_STATE_SCARED;
            hooked_fish->scared_timer = 2.0f;
            hooked_fish = NULL;
            return;
        }

        // BAIT EFFECT: Apply decay multiplier
        *meter -= (hooked_fish->base_decay * BAIT_CATALOG[p->equipped_bait].decay_multiplier) * dt;
        fight_time += dt;
        hooked_fish->tug_timer -= dt;
        if (hooked_fish->tug_timer <= 0) {
            *meter -= hooked_fish->tug_strength;
            hooked_fish->tug_timer = hooked_fish->tug_rate;
        }
    } else {
    	Vibration_Stop(); // Stop vibrate

        for (int i = 0; i < MAX_FISH_ON_SCREEN; i++) {
            if (pool[i].state == FISH_STATE_INACTIVE) {
                Spawn_Fish(&pool[i]);
            }
        }

        for (int i = 0; i < MAX_FISH_ON_SCREEN; i++) {
            Fish* fish = &pool[i];
            if (fish->state == FISH_STATE_FREE) {
                fish->x += FISH_SPEED * fish->direction * dt;
                if (fish->x < 0 || (fish->x + GOLDFISH_SPRITE_WIDTH) > SCREEN_WIDTH) {
                     fish->direction *= -1;
                }
                if ((fish->y + GOLDFISH_SPRITE_HEIGHT) > (SCREEN_HEIGHT - SAND_HEIGHT)) {
                    Spawn_Fish(fish);
                }
                float hook_x = p->boat_x;
                float hook_y = p->hook_y;
                if (hook_x > fish->x && hook_x < fish->x + GOLDFISH_SPRITE_WIDTH &&
                    hook_y > fish->y && hook_y < fish->y + GOLDFISH_SPRITE_HEIGHT)
                {
                    *is_fight_active = true;
                    *meter = FIGHT_START_METER;
                    fight_time = 0.0f;
                    fish->state = FISH_STATE_HOOKED;
                    hooked_fish = fish;


                    break;
                }
            } else if (fish->state == FISH_STATE_HOOKED) {
                 uint32_t random_val;
                 HAL_RNG_GenerateRandomNumber(&hrng, &random_val);
                fish->x = p->boat_x - (GOLDFISH_SPRITE_WIDTH / 2) + (random_val % 5 - 2);
                fish->y = p->hook_y - (GOLDFISH_SPRITE_HEIGHT / 2);
            } else if (fish->state == FISH_STATE_SCARED) {
                fish->scared_timer -= dt;
                if (fish->scared_timer <= 0) {
                    fish->state = FISH_STATE_FREE;
                }
            }
        }
    }
}

/**
 * @brief FIX: Draws the non-moving background once at the start.
 */
void Render_Background(void) {
    ILI9341_Fill_Screen(CYAN); // Sky
    ILI9341_Draw_Filled_Rectangle_Coord(0, WATER_LEVEL, SCREEN_WIDTH - 1, SCREEN_HEIGHT - 1, BLUE); // Water

    Draw_Sand();
}

/**
 * @brief FIX: Draws the static part of the HUD once at the start.
 */
void Render_Static_HUD(void) {
	ILI9341_Draw_Filled_Rectangle_Coord(0, 0, SCREEN_WIDTH - 1, 20, LIGHTGREY);
}


/**
 * @brief FIX: Renders only the changing elements of the game.
 */
void Render_Updates(Player* p, const Fish pool[], uint32_t time_left, bool is_fight_active, float meter)
{
    // --- Erase and Redraw Fish ---
	for (int i = 0; i < MAX_FISH_ON_SCREEN; i++) {
	    const Fish* fish = &pool[i];

	    // First, get the correct width and height for the fish
	    uint16_t w = 0, h = 0;
	    switch(fish->kind){
	        case FISH_KIND_GOLD:   w = GOLDFISH_SPRITE_WIDTH; h = GOLDFISH_SPRITE_HEIGHT; break;
	        case FISH_KIND_BLUE:   w = BLUEFISH_SPRITE_WIDTH; h = BLUEFISH_SPRITE_HEIGHT; break;
	        case FISH_KIND_PUFFER: w = PUFFERFISH_SPRITE_WIDTH; h = PUFFERFISH_SPRITE_HEIGHT; break;
	        case FISH_KIND_SHARK:  w = SHARK_SPRITE_WIDTH; h = SHARK_SPRITE_HEIGHT; break;
	    }

	    // 1. ALWAYS erase the fish from its old position to prevent ghosting
	    ILI9341_Draw_Filled_Rectangle_Coord(fish->old_x, fish->old_y, fish->old_x + w, fish->old_y + h, BLUE);

	    // 2. ONLY draw the fish at its new position if it's not inactive
	    if (fish->state != FISH_STATE_INACTIVE) {
	        Draw_Fish(fish->x, fish->y, fish->kind);
	    }
	}



    // --- Erase and Redraw Player ---
    // Erase old boat (draw sky over it)
    ILI9341_Draw_Filled_Rectangle_Coord(p->old_boat_x - BOAT_SPRITE_WIDTH / 2, WATER_LEVEL - BOAT_SPRITE_HEIGHT, p->old_boat_x + BOAT_SPRITE_WIDTH / 2, WATER_LEVEL, CYAN);
    // Erase old fishing line (draw water over it)
    ILI9341_Draw_Filled_Rectangle_Coord(p->old_boat_x, WATER_LEVEL, p->old_boat_x + 1, p->old_hook_y, BLUE);
    // Erase old hook
    ILI9341_Draw_Filled_Rectangle_Coord(p->old_boat_x - HOOK_SPRITE_WIDTH / 2, p->old_hook_y, p->old_boat_x + HOOK_SPRITE_WIDTH / 2, p->old_hook_y + HOOK_SPRITE_HEIGHT, BLUE);

    uint16_t hook_color = BAIT_CATALOG[p->equipped_bait].color;
    // Draw new boat sprite, line, and hook
    Draw_Boat(p->boat_x, WATER_LEVEL); // <-- THIS IS THE NEW LINE
    ILI9341_Draw_Filled_Rectangle_Coord(p->boat_x, WATER_LEVEL, p->boat_x + 1, p->hook_y, hook_color);

    // --- COLOR CHANGE: Get the equipped bait's color ---

    ILI9341_Draw_Filled_Rectangle_Coord(p->boat_x - 2, p->hook_y, p->boat_x + 1, p->hook_y + 3, hook_color);

    // --- Update HUD Text (only if it changes) ---
    char hud_text[30];
    if (time_left != last_time_left) {
        last_time_left = time_left;
        sprintf(hud_text, "TIME: %lu ", time_left); // Add space to erase last digit
        ILI9341_Draw_Text(hud_text, 5, 5, BLACK, 1, LIGHTGREY);
    }
    if (p->score != last_score) {
        last_score = p->score;
        sprintf(hud_text, "SCORE: $%ld", p->score);
        ILI9341_Draw_Text(hud_text, 150, 5, BLACK, 1, LIGHTGREY);
    }


    // --- Draw Fight Bar ---
    if (is_fight_active) {
        ILI9341_Draw_Hollow_Rectangle_Coord(40, 40, SCREEN_WIDTH - 40, 60, WHITE);
        uint16_t bar_width = (uint16_t)(((SCREEN_WIDTH - 84.0f) * meter) / FIGHT_TARGET);
        // Erase the old part of the bar
        ILI9341_Draw_Filled_Rectangle_Coord(42 + bar_width, 42, SCREEN_WIDTH - 42, 58, BLACK);
        if(bar_width > 0) {
            // Draw the new part
            ILI9341_Draw_Filled_Rectangle_Coord(42, 42, 42 + bar_width, 58, GREEN);
        }
    } else {
        // When fight ends, clear the bar area
        ILI9341_Draw_Filled_Rectangle_Coord(40, 40, SCREEN_WIDTH - 40, 60, GRAY);
    }
}

// --- NEW FUNCTION TO DRAW THE SAND ---
/**
 * @brief Draws the sand sprite at the bottom of the screen.
 */
void Draw_Sand(void) {
    // Calculate the top-left corner for drawing the sand
    uint16_t start_x = 0;
    uint16_t start_y = SCREEN_HEIGHT - SAND_SPRITE_HEIGHT;

    for (uint16_t j = 0; j < SAND_SPRITE_HEIGHT; j++) {
        for (uint16_t i = 0; i < SAND_SPRITE_WIDTH; i++) {
            uint16_t current_pixel_color = sand_sprite_data[j * SAND_SPRITE_WIDTH + i];
            ILI9341_Draw_Pixel(start_x + i, start_y + j, current_pixel_color);
        }
    }
}


/**
  * @brief  Rx Transfer completed callback.
  * @param  huart: UART handle
  * @retval None
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if(huart->Instance == USART3)
    {
        // --- ADD THIS LINE TO ECHO THE CHARACTER BACK ---
        HAL_UART_Transmit(&huart3, (uint8_t*)&received_char, 1, 10);
        // ---------------------------------------------

        new_key_pressed = true; // Set a flag that we got a key
        // Start listening for the next character
        HAL_UART_Receive_IT(&huart3, (uint8_t*)&received_char, 1);
    }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
