#ifndef GAME_H_
#define GAME_H_

#include <stdint.h>
#include <stdbool.h>
#include "ILI9341_STM32_Driver.h"

//================================================================
// 1. GAME CONSTANTS
//================================================================

// --- NEW: Game State Machine ---
typedef enum {
    GAME_STATE_PLAY,
    GAME_STATE_BOAT_SHOP,
    GAME_STATE_BAIT_SHOP,
    GAME_STATE_OVER
} GameState;

// --- Screen and Layout ---
#define SCREEN_WIDTH    240
#define SCREEN_HEIGHT   320
#define WATER_LEVEL     135
#define SAND_HEIGHT     30 // <-- NEW: Height of the sand at the bottom

// --- NEW: Shop UI Colors ---
#define SHOP_BG_COLOR           0x000B // Dark Blue (#000B58)
#define SHOP_HEADER_BG_COLOR    0xEC84 // Orange (#EF7722)

// --- Gameplay Timers ---
#define GAME_DURATION_S 120
#define FIGHT_TIMEOUT_S 6

// --- Player and Hook ---
#define PLAYER_START_SCORE 0
#define FISH_CATCH_SCORE   20
#define HOOK_SPEED         100.0f

// --- Fight Minigame Mechanics ---
#define FIGHT_TARGET      100.0f
#define FIGHT_START_METER 35.0f
#define FIGHT_PRESS_GAIN  12.0f

// --- Fish Population ---
#define MAX_FISH_ON_SCREEN 5

// --- COLOR FIXES ---
#define GRAY   0x8410
#define BROWN  0xA145

//================================================================
// 2. ENUMERATIONS AND STRUCTS (Game Objects)
//================================================================

// --- NEW: Boat and Bait Types ---
typedef enum { BOAT_NORMAL, BOAT_SHARK, BOAT_SPEEDBOAT, BOAT_SAILOR, BOAT_COUNT } BoatType;
typedef enum { BAIT_REGULAR, BAIT_GOOD, BAIT_GREAT, BAIT_ULTIMATE, BAIT_COUNT } BaitType;

typedef enum {
    FISH_KIND_GOLD, FISH_KIND_BLUE, FISH_KIND_PUFFER, FISH_KIND_SHARK
} FishKind;

typedef enum {
    FISH_STATE_FREE, FISH_STATE_HOOKED, FISH_STATE_SCARED, FISH_STATE_INACTIVE
} FishState;

typedef struct {
    float x, y;
    float old_x, old_y; // Track previous position
    int direction;
    FishKind kind;
    FishState state;
    float base_decay, tug_strength, tug_rate, tug_timer, scared_timer;
} Fish;

typedef struct {
    long score;
    float boat_x;
    float old_boat_x; // Track previous position
    float hook_y;
    float old_hook_y; // Track previous position
    BoatType equipped_boat;
    BaitType equipped_bait;
    bool boats_owned[BOAT_COUNT];
    bool baits_owned[BAIT_COUNT]; // <-- CHANGED from quantity to owned
} Player;

//================================================================
// 3. FUNCTION PROTOTYPES (The Game's Engine)
//================================================================
void Game_Init(Player* player, Fish fish_pool[]);
void Handle_Input(Player* player, bool* fight_active, float* fight_meter);
void Update__Game_Logic(Player* player, Fish fish_pool[], bool* fight_active, float* fight_meter, float dt);
void Render_Graphics(const Player* player, const Fish fish_pool[], uint32_t time_left, bool fight_active, float fight_meter);

//================================================================
// 4. SHOP CATALOGS
//================================================================

// --- NEW: Boat Item Properties ---
typedef struct {
    const char* name;
    int price;
} BoatInfo;

static const BoatInfo BOAT_CATALOG[BOAT_COUNT] = {
    [BOAT_NORMAL]    = {"Normal",    0},
    [BOAT_SHARK]     = {"Shark",     50},
    [BOAT_SPEEDBOAT] = {"Speedboat", 90},
    [BOAT_SAILOR]    = {"Sailor",    150}
};

// --- NEW: Bait Item Properties ---
typedef struct {
    const char* name;
    int price;
    float decay_multiplier; // Makes fight bar drain slower (e.g., 0.8 = 20% easier)
    uint16_t color; // <-- NEW: Color for this bait
} BaitInfo;

static const BaitInfo BAIT_CATALOG[BAIT_COUNT] = {
	    [BAIT_REGULAR]  = {"Regular",   0,   1.0f, WHITE},
	    [BAIT_GOOD]     = {"Good",      40,  0.6f, GREEN},
	    [BAIT_GREAT]    = {"Great",     100, 0.3f, 0xFD20},
	    [BAIT_ULTIMATE] = {"Ultimate",  200, 0.1f, YELLOW}
};

#endif /* GAME_H_ */
